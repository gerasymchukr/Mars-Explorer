"""Plugin: remove every comment from the project's source files.

Safe by default: results go to a NEW folder and the originals are untouched.

    python plugins/strip_comments.py                    # -> ../mars_explorer_nocomments
    python plugins/strip_comments.py --out clean_copy   # custom output folder
    python plugins/strip_comments.py --check            # only report, write nothing
    python plugins/strip_comments.py --in-place         # overwrite the sources
    python plugins/strip_comments.py --docstrings       # also drop docstrings

Handled: .py (# comments, via the tokenizer, so '#' inside strings is kept),
.toml (# comments), .css / .js (/* */ and //), .html (<!-- -->).
Python files are verified: the syntax tree must be identical after stripping
(ignoring docstrings when --docstrings is used), otherwise the file is left
unchanged and reported as an error.
Kept on purpose: the shebang line and the "# -*- coding -*-" line, because
removing them changes how Python runs the file.
Comments written inside Python strings (for example the CSS in theme.py or the
JavaScript in mars_geo.py) are string data, not Python comments. Use
--embedded to strip those too.
"""
import argparse
import ast
import io
import re
import shutil
import sys
import tokenize
from pathlib import Path

SKIP_DIRS = {".git", "__pycache__", ".venv", "venv", "node_modules", "plugins"}
CODING = re.compile(r"^[ \t\f]*#.*?coding[:=][ \t]*[-\w.]+")


def _split(text):
    return text.splitlines(keepends=True)


def _eol(line):
    return line[len(line.rstrip("\r\n")):]


def strip_python(text, docstrings=False):
    lines = _split(text)
    cuts = {}
    for tok in tokenize.generate_tokens(io.StringIO(text).readline):
        if tok.type != tokenize.COMMENT:
            continue
        row, col = tok.start
        keep = (row == 1 and tok.string.startswith("#!")) or (
            row <= 2 and CODING.match(lines[row - 1])
        )
        if not keep:
            cuts[row] = col
    out = []
    for number, line in enumerate(lines, start=1):
        if number not in cuts:
            out.append(line)
            continue
        head = line[: cuts[number]].rstrip()
        if head:
            out.append(head + _eol(line))
    result = "".join(out)
    if docstrings:
        result = _drop_docstrings(result)
    return result


def _drop_docstrings(text):
    tree = ast.parse(text)
    spans = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                             ast.AsyncFunctionDef)):
            body = node.body
            first = body[0] if body else None
            if (isinstance(first, ast.Expr)
                    and isinstance(first.value, ast.Constant)
                    and isinstance(first.value.value, str)):
                spans.append((first, len(body) == 1))
    lines = _split(text)
    for node, only in sorted(spans, key=lambda s: -s[0].lineno):
        start, end = node.lineno - 1, node.end_lineno
        if only:
            indent = re.match(r"\s*", lines[start]).group(0)
            lines[start:end] = [indent + "pass" + _eol(lines[start])]
        else:
            del lines[start:end]
    return "".join(lines)


def _scan_c_style(text, line_comments, block=("/*", "*/")):
    """Remove /* */ and // comments while skipping quoted strings."""
    out, i, n = [], 0, len(text)
    while i < n:
        c = text[i]
        if c in "\"'`":
            j = i + 1
            while j < n and text[j] != c:
                j += 2 if text[j] == "\\" else 1
            out.append(text[i:j + 1])
            i = j + 1
        elif text.startswith(block[0], i):
            j = text.find(block[1], i + 2)
            j = n if j < 0 else j + 2
            out.append("\n" * text.count("\n", i, j))
            i = j
        elif line_comments and text.startswith("//", i) and (
                i == 0 or text[i - 1] != ":"):
            j = text.find("\n", i)
            i = n if j < 0 else j
        else:
            out.append(c)
            i += 1
    return _tidy("".join(out))


def strip_css(text):
    return _scan_c_style(text, line_comments=False)


def strip_js(text):
    return _scan_c_style(text, line_comments=True)


def strip_html(text):
    text = re.sub(r"<!--.*?-->", "", text, flags=re.S)
    return _tidy(text)


def strip_hash(text):
    out = []
    for line in _split(text):
        if line.startswith("#!"):
            out.append(line)
            continue
        quoted = None
        cut = None
        for i, ch in enumerate(line):
            if quoted:
                if ch == quoted and line[i - 1] != "\\":
                    quoted = None
            elif ch in "\"'":
                quoted = ch
            elif ch == "#":
                cut = i
                break
        if cut is None:
            out.append(line)
        else:
            head = line[:cut].rstrip()
            if head:
                out.append(head + _eol(line))
    return "".join(out)


def _tidy(text):
    """Trim trailing spaces and collapse the blank runs comments leave."""
    lines = [ln.rstrip(" \t\r\n") for ln in text.split("\n")]
    out = []
    for ln in lines:
        if not ln and out and not out[-1]:
            continue
        out.append(ln)
    return "\n".join(out)


HANDLERS = {
    ".py": strip_python,
    ".toml": strip_hash,
    ".css": strip_css,
    ".js": strip_js,
    ".html": strip_html,
}

EMBEDDED = re.compile(
    r'(?P<q>"""|\'\'\')(?P<body>.*?)(?P=q)', re.S
)


def strip_embedded(text):
    """Strip /* */ and // comments inside triple-quoted CSS/JS strings."""
    def fix(match):
        body = match.group("body")
        if "/*" not in body and "//" not in body:
            return match.group(0)
        cleaned = _scan_c_style(body, line_comments="function" in body
                                or "const " in body)
        return match.group("q") + cleaned + match.group("q")
    return EMBEDDED.sub(fix, text)


def process(path, args):
    suffix = path.suffix.lower()
    handler = HANDLERS.get(suffix)
    if handler is None:
        return None
    raw = path.read_bytes().decode("utf-8")
    if suffix == ".py":
        new = strip_python(raw, docstrings=args.docstrings)
        if args.embedded:
            new = strip_embedded(new)
        _verify(raw, new, args.docstrings or args.embedded)
    else:
        new = handler(raw)
    return raw, new


def _verify(before, after, loose):
    try:
        a, b = ast.parse(before), ast.parse(after)
    except SyntaxError as error:
        raise ValueError(f"does not parse: {error}") from error
    if loose:
        return
    if ast.dump(a) != ast.dump(b):
        raise ValueError("syntax tree changed, file skipped")


def iter_files(root):
    for path in sorted(root.rglob("*")):
        if path.is_file() and not (set(path.relative_to(root).parts)
                                   & SKIP_DIRS):
            yield path


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    parser.add_argument("root", nargs="?", default=None,
                        help="project folder (default: parent of plugins/)")
    parser.add_argument("--out", help="output folder for the cleaned copy")
    parser.add_argument("--in-place", action="store_true",
                        help="overwrite the original files")
    parser.add_argument("--check", action="store_true",
                        help="report only, write nothing")
    parser.add_argument("--docstrings", action="store_true",
                        help="also remove Python docstrings")
    parser.add_argument("--embedded", action="store_true",
                        help="also strip comments inside triple-quoted "
                             "CSS/JS strings in .py files")
    args = parser.parse_args(argv)

    root = Path(args.root or Path(__file__).resolve().parent.parent).resolve()
    out = None
    if not args.in_place and not args.check:
        out = Path(args.out) if args.out else root.with_name(
            root.name + "_nocomments")
        out = out.resolve()
        if out == root or root in out.parents:
            sys.exit("output folder must be outside the project folder")
        shutil.rmtree(out, ignore_errors=True)

    changed = errors = 0
    for path in iter_files(root):
        target = (out / path.relative_to(root)) if out else path
        result, failed = None, None
        try:
            result = process(path, args)
        except (ValueError, UnicodeDecodeError, tokenize.TokenError) as error:
            failed = error
        if failed:
            errors += 1
            print(f"ERROR  {path.relative_to(root)}: {failed}")
        if out:
            target.parent.mkdir(parents=True, exist_ok=True)
        if result is None or failed:
            if out:
                shutil.copy2(path, target)
            continue
        raw, new = result
        if new != raw:
            changed += 1
            print(f"strip  {path.relative_to(root)}  "
                  f"({len(raw)} -> {len(new)} bytes)")
        if not args.check:
            target.write_bytes(new.encode("utf-8"))
    action = "would change" if args.check else "changed"
    print(f"\n{action} {changed} file(s), {errors} error(s)")
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
